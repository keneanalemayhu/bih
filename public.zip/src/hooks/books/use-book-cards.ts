// @/hooks/use-book-cards.ts

export function useBookCards() {
  return [
    {
      title: "The Great Gatsby",
      description: "F. Scott Fitzgerald",
      src: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f7/TheGreatGatsby_1925jacket.jpeg/640px-TheGreatGatsby_1925jacket.jpeg",
      ctaText: "Exchange",
      ctaLink: "https://en.wikipedia.org/wiki/The_Great_Gatsby",
      content: () => (
        <p>
          <em>The Great Gatsby</em> is a 1925 novel by F. Scott Fitzgerald. Set in the Jazz Age, it tells the story of Jay Gatsby’s dream for Daisy Buchanan, touching on themes of wealth, love, and the American Dream.
        </p>
      ),
    }
    {
      title: "Things Fall Apart",
      description: "Chinua Achebe",
      src: "https://upload.wikimedia.org/wikipedia/en/6/65/ThingsFallApart.jpg",
      ctaText: "Exchange",
      ctaLink: "https://en.wikipedia.org/wiki/Things_Fall_Apart",
      content: () => (
        <p>
          <em>Things Fall Apart</em> (1958) by Chinua Achebe explores the effects of colonialism on traditional Igbo society. Through Okonkwo’s story, it critiques the destructive impact of British rule in Africa.
        </p>
      ),
    },
    {
      title: "Fikir Eske Mekabir",
      description: "Haddis Alemayehu",
      src: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Fiker_Esike_Mekaber.jpg/800px-Fiker_Esike_Mekaber.jpg",
      ctaText: "Exchange",
      ctaLink: "https://en.wikipedia.org/wiki/Fikir_Eske_Mekabir",
      content: () => (
        <p>
          <em>Fikir Eske Mekabir</em> is a revered Ethiopian novel delving into love, tradition, and social structures in 20th-century Ethiopia. Haddis Alemayehu's masterful storytelling makes it an enduring classic.
        </p>
      ),
    },
    {
      title: "The Alchemist",
      description: "Paulo Coelho",
      src: "https://upload.wikimedia.org/wikipedia/en/c/c4/TheAlchemist.jpg",
      ctaText: "Exchange",
      ctaLink: "https://en.wikipedia.org/wiki/The_Alchemist_(novel)",
      content: () => (
        <p>
          In <em>The Alchemist</em>, Paulo Coelho follows Santiago’s journey to fulfill his personal legend. This philosophical tale of purpose and destiny has inspired millions worldwide.
        </p>
      ),
    },
    {
      title: "Oromay",
      description: "Bealu Girma",
      src: "https://i.imgur.com/QwUqxAD.jpeg",
      ctaText: "Exchange",
      ctaLink: "https://en.wikipedia.org/wiki/Bealu_Girma",
      content: () => (
        <p>
          <em>Oromay</em> is a political novel by Bealu Girma that critiques the Derg regime in Ethiopia. The book's bold commentary is believed to have led to the author's forced disappearance.
        </p>
      ),
    },
  ];
}
